/**
 * Configuration de l'app.
 *
 * DIGEST_BASE_URL : racine du CDN où le pipeline `ingest/` publie les éditions
 * (voir ingest/README.md). Avec GitHub Pages sur la branche `digests` :
 *   https://<user>.github.io/<repo>
 * Laisser vide pour rester sur les données de démonstration (MockNewsGateway).
 */
export const DIGEST_BASE_URL = 'https://jochsoro.github.io/news-digest';
