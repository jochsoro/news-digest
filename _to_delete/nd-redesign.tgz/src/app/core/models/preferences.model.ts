import { CategoryId } from './category.model';

export type DigestLength = 'short' | 'standard' | 'detailed';

/**
 * Choix explicites de l'utilisateur, persistés localement (Capacitor Preferences).
 */
export interface UserPreferences {
  /** id de la région active (celle dont on lit le digest). */
  activeRegionId: string;
  /** Thèmes cochés. Vide = tous. */
  selectedCategories: CategoryId[];
  /** Langue de lecture préférée (ISO 639-1). */
  language: string;
  /** Heure de réception du digest quotidien, format HH:mm (24h). */
  digestTime: string;
  /** Longueur de résumé voulue. */
  digestLength: DigestLength;
  /** Notification quotidienne activée. */
  notificationsEnabled: boolean;
}

/**
 * Signaux implicites accumulés par l'usage, pour la pondération.
 * Jamais envoyés tels quels à un tiers — restent sur l'appareil.
 */
export interface EngagementSignals {
  /** Nombre d'ouvertures par thème. */
  opensByCategory: Partial<Record<CategoryId, number>>;
  /** Nombre de mises en favori par thème. */
  savesByCategory: Partial<Record<CategoryId, number>>;
  /** Nombre de partages par thème. */
  sharesByCategory: Partial<Record<CategoryId, number>>;
  /** ids d'articles/blocs masqués explicitement ("moins de ça"). */
  dismissed: string[];
}

export const DEFAULT_PREFERENCES: UserPreferences = {
  activeRegionId: 'world',
  selectedCategories: [],
  language: 'fr',
  digestTime: '07:30',
  digestLength: 'standard',
  notificationsEnabled: true,
};

export const EMPTY_SIGNALS: EngagementSignals = {
  opensByCategory: {},
  savesByCategory: {},
  sharesByCategory: {},
  dismissed: [],
};
