import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { PreferencesService } from '../../core/services/preferences.service';
import { NotificationService } from '../../core/services/notification.service';
import { DigestLength } from '../../core/models/preferences.model';

@Component({
  selector: 'app-settings-page',
  imports: [FormsModule],
  templateUrl: './settings.page.html',
  styleUrl: './settings.page.scss',
})
export class SettingsPage {
  private readonly prefsSvc = inject(PreferencesService);
  private readonly notifications = inject(NotificationService);

  readonly prefs = this.prefsSvc.prefs;

  readonly languages = [
    { code: 'fr', label: 'Français' },
    { code: 'en', label: 'English' },
    { code: 'es', label: 'Español' },
  ];

  readonly lengths: { value: DigestLength; label: string; hint: string }[] = [
    { value: 'short', label: 'Court', hint: '1–2 phrases par thème' },
    { value: 'standard', label: 'Standard', hint: '3–4 phrases par thème' },
    { value: 'detailed', label: 'Détaillé', hint: 'résumé développé' },
  ];

  async setLanguage(language: string): Promise<void> {
    await this.prefsSvc.update({ language });
  }

  async setLength(digestLength: DigestLength): Promise<void> {
    await this.prefsSvc.update({ digestLength });
  }

  async setTime(event: Event): Promise<void> {
    const digestTime = (event.target as HTMLInputElement).value;
    await this.prefsSvc.update({ digestTime });
    if (this.prefs().notificationsEnabled) {
      await this.notifications.scheduleDaily(digestTime);
    }
  }

  async toggleNotifications(): Promise<void> {
    const enabled = !this.prefs().notificationsEnabled;
    if (enabled) {
      const granted = await this.notifications.requestPermission();
      await this.prefsSvc.update({ notificationsEnabled: granted });
      if (granted) {
        await this.notifications.scheduleDaily(this.prefs().digestTime);
      }
    } else {
      await this.prefsSvc.update({ notificationsEnabled: false });
      await this.notifications.cancel();
    }
  }
}
