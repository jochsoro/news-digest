import { Component, computed, effect, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';

import { NewsService } from '../../core/services/news.service';
import { PreferencesService } from '../../core/services/preferences.service';
import { PersonalizationService } from '../../core/services/personalization.service';
import { GeoTaxonomyService } from '../../core/services/geo-taxonomy.service';
import { DigestRow } from '../../shared/components/digest-row/digest-row';
import { CategoryFilter } from '../../shared/components/category-filter/category-filter';
import { SummaryBlock } from '../../core/models/article.model';
import { CategoryId } from '../../core/models/category.model';

@Component({
  selector: 'app-digest-page',
  imports: [RouterLink, DigestRow, CategoryFilter],
  templateUrl: './digest.page.html',
  styleUrl: './digest.page.scss',
})
export class DigestPage {
  private readonly news = inject(NewsService);
  private readonly prefsSvc = inject(PreferencesService);
  private readonly perso = inject(PersonalizationService);
  private readonly geo = inject(GeoTaxonomyService);

  readonly loading = this.news.loading;
  readonly error = this.news.error;
  readonly prefs = this.prefsSvc.prefs;

  /** Thème déplié dans la liste (un seul à la fois, comme un journal qu'on feuillette). */
  readonly expanded = signal<CategoryId | null>(null);

  readonly region = computed(() => this.geo.getById(this.prefsSvc.activeRegionId()));

  /** Chaîne « Afrique · Côte d'Ivoire » au-dessus du nom de la région. */
  readonly parentTrail = computed(() => {
    const path = this.geo.getPath(this.prefsSvc.activeRegionId());
    return path.slice(1, -1).map((r) => r.name).join(' · ');
  });

  readonly now = new Date();
  readonly weekday = this.now.toLocaleDateString('fr-FR', { weekday: 'long' });
  readonly dayMonth = this.now.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' });

  readonly blocks = computed<SummaryBlock[]>(() => {
    const digest = this.news.digest();
    if (!digest) return [];
    return this.perso.personalize(digest, this.prefsSvc.prefs(), this.prefsSvc.signals());
  });

  readonly lead = computed(() => this.blocks()[0] ?? null);
  readonly others = computed(() => this.blocks().slice(1));

  constructor() {
    effect(() => {
      const regionId = this.prefsSvc.activeRegionId();
      this.expanded.set(null);
      this.news.loadDigest(regionId);
    });
  }

  toggle(cat: CategoryId): void {
    this.expanded.update((cur) => (cur === cat ? null : cat));
  }

  onToggleCategory(id: CategoryId): void {
    this.prefsSvc.toggleCategory(id);
  }

  onClearCategories(): void {
    this.prefsSvc.update({ selectedCategories: [] });
  }

  onOpened(block: SummaryBlock): void {
    this.prefsSvc.recordOpen(block.category);
  }

  onSaved(block: SummaryBlock): void {
    this.prefsSvc.recordSave(block.category);
  }

  onDismissed(block: SummaryBlock): void {
    const digest = this.news.digest();
    if (digest) this.prefsSvc.dismiss(this.perso.blockId(digest, block));
  }

  refresh(): void {
    this.news.refresh(this.prefsSvc.activeRegionId());
  }
}
