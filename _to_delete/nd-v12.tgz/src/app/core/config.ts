/**
 * Configuration de l'app.
 *
 * DIGEST_BASE_URL : racine où le pipeline `ingest/` publie les éditions
 * (voir ingest/README.md).
 *
 *  - Production (app native, site déployé) : le CDN — GitHub Pages sur la
 *    branche `digests` : https://<user>.github.io/<repo>
 *  - Développement (`npm start` sur localhost) : un serveur local qui sert
 *    `ingest/out` → `npm run digest:local` à la racine du projet.
 *  - Surcharge ponctuelle sans rebuild : dans la console du navigateur,
 *    localStorage.setItem('nd.digestBase', 'https://…') puis recharger ;
 *    localStorage.removeItem('nd.digestBase') pour revenir au défaut.
 *
 * Chaîne vide → données de démonstration (MockNewsGateway).
 */
const PRODUCTION_BASE_URL = 'https://jochsoro.github.io/news-digest';
const LOCAL_BASE_URL = 'http://localhost:8787';

export const DIGEST_BASE_URL: string = resolveBaseUrl();

function resolveBaseUrl(): string {
  try {
    const override = localStorage.getItem('nd.digestBase');
    if (override !== null) return override.trim();
    const host = location.hostname;
    if (host === 'localhost' || host === '127.0.0.1') return LOCAL_BASE_URL;
  } catch {
    /* pas de window (tests) : défaut production */
  }
  return PRODUCTION_BASE_URL;
}
