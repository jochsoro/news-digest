import { Injectable } from '@angular/core';
import { inject } from '@angular/core';
import { Digest } from '../models/digest.model';
import { GeoTaxonomyService } from './geo-taxonomy.service';
import { buildMockDigest } from '../data/mock-digests.data';

/**
 * Contrat d'accès aux digests. L'app dépend de cette abstraction, pas d'une
 * source concrète : on branche le mock en dev, une implémentation HTTP vers
 * le backend en prod, sans toucher au reste (voir provider dans app.config.ts).
 */
export abstract class NewsGateway {
  /** Renvoie le digest mutualisé d'une région pour une date (YYYY-MM-DD). */
  abstract fetchDigest(regionId: string, date: string): Promise<Digest>;
}

/**
 * Implémentation de démonstration : fabrique un digest localement.
 * Simule une petite latence réseau pour que les états de chargement de l'UI
 * soient réalistes.
 */
@Injectable()
export class MockNewsGateway extends NewsGateway {
  private readonly geo = inject(GeoTaxonomyService);

  async fetchDigest(regionId: string, date: string): Promise<Digest> {
    await this.delay(350 + Math.random() * 400);
    const region = this.geo.getById(regionId) ?? this.geo.root;
    return buildMockDigest(region.id, region.name, region.level === 'world', date);
  }

  private delay(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}

/**
 * Esquisse d'implémentation HTTP pour la production (non branchée).
 * Le backend expose /digests/{regionId}?date=YYYY-MM-DD et renvoie déjà les
 * blocs résumés par le LLM. À activer en changeant le provider.
 *
 *   @Injectable()
 *   export class HttpNewsGateway extends NewsGateway {
 *     private http = inject(HttpClient);
 *     fetchDigest(regionId: string, date: string) {
 *       return firstValueFrom(
 *         this.http.get<Digest>(`${API}/digests/${regionId}`, { params: { date } })
 *       );
 *     }
 *   }
 */
