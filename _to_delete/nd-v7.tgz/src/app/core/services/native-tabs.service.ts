import { DOCUMENT, Injectable, inject } from '@angular/core';
import { Router } from '@angular/router';
import { Capacitor, registerPlugin, type PluginListenerHandle } from '@capacitor/core';

interface TabBarMetrics {
  height: number;
  safeBottom: number;
  /** Largeur « regular » : grand écran ou écran déplié. */
  regularWidth: boolean;
}

interface LiquidTabBarPlugin {
  configure(options: {
    items: { key: string; title: string; symbol: string }[];
    active?: string;
    visible?: boolean;
  }): Promise<TabBarMetrics>;
  setActive(options: { key: string }): Promise<void>;
  setVisible(options: { visible: boolean }): Promise<TabBarMetrics>;
  metrics(): Promise<TabBarMetrics>;
  addListener(
    event: 'select',
    cb: (data: { key: string }) => void,
  ): Promise<PluginListenerHandle>;
}

const LiquidTabBar = registerPlugin<LiquidTabBarPlugin>('LiquidTabBar');

/** Un onglet = une route + un symbole SF pour la barre native. */
const TABS = [
  { key: '/', title: 'Actus', symbol: 'newspaper' },
  { key: '/profile', title: 'Profil', symbol: 'person.crop.circle' },
];

/** Seuil au-delà duquel on passe au rail latéral plutôt qu'à une barre basse. */
const WIDE_BREAKPOINT = 700;

/**
 * Sur iOS, délègue la barre d'onglets à une vraie `UITabBar` du système
 * (Liquid Glass authentique sur iOS 26) et masque le dock web. Partout
 * ailleurs — Android, web — le dock web reste la barre d'onglets.
 *
 * Sur les écrans larges (iPad, iPhone pliant déplié), la barre basse n'est
 * plus la bonne forme : on masque la barre native et on laisse le rail
 * latéral CSS prendre le relais.
 */
@Injectable({ providedIn: 'root' })
export class NativeTabsService {
  private readonly router = inject(Router);
  private readonly doc = inject(DOCUMENT);

  private available = false;
  private usingNative = false;

  async init(): Promise<void> {
    if (Capacitor.getPlatform() !== 'ios' || !Capacitor.isPluginAvailable('LiquidTabBar')) {
      return;
    }

    try {
      const metrics = await LiquidTabBar.configure({
        items: TABS,
        active: this.keyFor(this.router.url),
        visible: !this.isWide(),
      });
      this.available = true;
      this.apply(metrics);

      // Touche sur un onglet natif → navigation Angular.
      await LiquidTabBar.addListener('select', ({ key }) => {
        if (this.keyFor(this.router.url) !== key) {
          this.router.navigateByUrl(key);
        }
      });

      // Navigation Angular → onglet natif marqué actif.
      this.router.events.subscribe(() => {
        if (this.available) {
          LiquidTabBar.setActive({ key: this.keyFor(this.router.url) }).catch(() => {});
        }
      });

      // Rotation, redimensionnement, dépliage : on réévalue la forme.
      const resync = () => this.resync();
      window.addEventListener('resize', resync);
      window.addEventListener('orientationchange', resync);
    } catch {
      // Plugin absent de ce build : le dock web reste en place, rien à signaler.
      this.available = false;
      this.doc.documentElement.removeAttribute('data-native-tabs');
    }
  }

  private isWide(): boolean {
    return window.innerWidth >= WIDE_BREAKPOINT;
  }

  private async resync(): Promise<void> {
    if (!this.available) return;
    try {
      const metrics = await LiquidTabBar.setVisible({ visible: !this.isWide() });
      this.apply(metrics);
    } catch {
      /* ignoré : l'affichage reste tel quel */
    }
  }

  /**
   * Reporte la hauteur de la barre native dans les variables CSS, pour que
   * les pages réservent la bonne marge sous leur contenu.
   */
  private apply(metrics: TabBarMetrics): void {
    const root = this.doc.documentElement;
    const wide = this.isWide() || metrics.regularWidth;
    this.usingNative = !wide;

    if (this.usingNative) {
      root.setAttribute('data-native-tabs', '');
      // `height` inclut la zone sûre, que le CSS ajoute déjà de son côté.
      const bar = Math.max(0, metrics.height - metrics.safeBottom);
      root.style.setProperty('--nav-h', `${Math.round(bar)}px`);
    } else {
      root.removeAttribute('data-native-tabs');
      root.style.removeProperty('--nav-h');
    }
  }

  /** Quelle route porte l'onglet actif (les sous-pages héritent de leur parent). */
  private keyFor(url: string): string {
    return url.startsWith('/profile') || url.startsWith('/settings') ? '/profile' : '/';
  }
}
