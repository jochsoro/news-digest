import { Injectable, inject, signal } from '@angular/core';
import { Digest } from '../models/digest.model';
import { NewsGateway } from './news-gateway';

/**
 * Façade d'accès aux digests côté UI. Gère le cache en mémoire (un digest par
 * clé region+date, cohérent avec le modèle mutualisé : on ne retélécharge pas
 * le même digest) et les états de chargement/erreur exposés en signals.
 */
@Injectable({ providedIn: 'root' })
export class NewsService {
  private readonly gateway = inject(NewsGateway);
  private readonly cache = new Map<string, Digest>();

  readonly loading = signal(false);
  readonly error = signal<string | null>(null);
  readonly digest = signal<Digest | null>(null);

  /** Date du jour au format YYYY-MM-DD (fuseau local). */
  static today(): string {
    const d = new Date();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${d.getFullYear()}-${mm}-${dd}`;
  }

  async loadDigest(regionId: string, date = NewsService.today()): Promise<void> {
    const key = `${regionId}|${date}`;
    this.error.set(null);

    const cached = this.cache.get(key);
    if (cached) {
      this.digest.set(cached);
      return;
    }

    this.loading.set(true);
    try {
      const d = await this.gateway.fetchDigest(regionId, date);
      this.cache.set(key, d);
      this.digest.set(d);
    } catch (e) {
      this.error.set('Impossible de charger le digest. Réessaie plus tard.');
      this.digest.set(null);
      console.error(e);
    } finally {
      this.loading.set(false);
    }
  }

  /** Force le rechargement (pull-to-refresh). */
  async refresh(regionId: string, date = NewsService.today()): Promise<void> {
    this.cache.delete(`${regionId}|${date}`);
    await this.loadDigest(regionId, date);
  }
}
