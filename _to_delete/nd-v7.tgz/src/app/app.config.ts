import {
  ApplicationConfig,
  provideBrowserGlobalErrorListeners,
  provideAppInitializer,
  inject,
} from '@angular/core';
import { provideRouter, withViewTransitions } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';

import { routes } from './app.routes';
import { NewsGateway, MockNewsGateway } from './core/services/news-gateway';
import { PreferencesService } from './core/services/preferences.service';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes, withViewTransitions()),
    provideHttpClient(),

    // Source d'actus : mock en dev. Pour la prod, remplacer par HttpNewsGateway.
    { provide: NewsGateway, useClass: MockNewsGateway },

    // Hydrate les préférences depuis le disque avant le premier rendu.
    provideAppInitializer(() => inject(PreferencesService).load()),
  ],
};
